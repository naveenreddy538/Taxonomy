package com.naveen.model.listeners;

import com.liferay.document.library.kernel.model.DLFileEntry;
import com.liferay.document.library.kernel.model.DLFolder;
import com.liferay.portal.kernel.exception.ModelListenerException;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.BaseModelListener;
import com.liferay.asset.kernel.model.AssetCategory;
import com.liferay.asset.kernel.service.AssetCategoryLocalServiceUtil;
import com.liferay.asset.kernel.service.AssetEntryLocalServiceUtil;

import java.util.ArrayList;
import java.util.List;

public class DLFileEntryListener extends BaseModelListener<DLFileEntry> {
	public void onBeforeCreate(DLFileEntry dlFileEntry) throws ModelListenerException {

		_log.info("This method will be called before create document");
		try {
			System.out.println("This is onBeforeCreatet for login" + dlFileEntry.getFolder());
		} catch (PortalException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}	
	
	public void onAfterCreate(DLFileEntry  ae) throws ModelListenerException {
		_log.info("upload document! - onAfterCreate");
		System.out.println("Tiger@@@@@@@@@@@ onAfterCreate :");
	}
	

	public void onBeforeRemove(DLFileEntry dlFileEntry) throws ModelListenerException {
		_log.info("This method will be called before DELETE document");
		System.out.println("This is onBeforeRemove for login");
	}

public void onBeforeUpdate(DLFileEntry newDLFileEntry) throws ModelListenerException {
try {
	_log.info("This method will be called before UPDATE document"+newDLFileEntry.getFolder());
} catch (PortalException e1) {
	// TODO Auto-generated catch block
	e1.printStackTrace();
}
try {	
	String[] filenames=fullPath(newDLFileEntry).split("/");	
	 List<AssetCategory> categories = AssetCategoryLocalServiceUtil.getCategories();	
	 String  doctype="";
	 System.out.println("This is onBeforeCreatet for login filenames.length" + filenames.length);
	// long[] assetType=new long[filenames.length];
	 ArrayList < Long > assetType = new ArrayList < Long > ();	
	 String[] tagNames = null;
	 int i=0;
		 for(String fileName:filenames ) {			 
			 for(AssetCategory category:categories) {
				 //System.out.println("This is onBeforeUpdate for category name"+category.getName());
				 if(category.getName().equals(fileName)) {									
					 doctype=doctype.concat(category.getName());
					 doctype=doctype.concat(",");					 
					 assetType.add(category.getCategoryId());					
					 i=i++;					
				 }
			 }
		 }
		 System.out.println("Tiger@@@@@@@@@@@@@doctype  assetType.length :: "+assetType.size());
		 System.out.println("Tiger@@@@@@@@@@@@@doctype  :: "+doctype.toString());
		 long[] arr = new long[assetType.size()];
		 int index = 0;		 
		 for (Long value : assetType) {
	         arr[index++] = value;
	      }
		 System.out.println("Tiger@@@@@@@@@@@@@doctype  arr.length :: "+arr.length);
		 AssetEntryLocalServiceUtil.updateEntry(newDLFileEntry.getUserId(),
			  newDLFileEntry.getGroupId(),DLFileEntry.class.getName(),
			  newDLFileEntry.getPrimaryKey(), arr, tagNames);
		
} catch (PortalException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

}

	private static Log _log = LogFactoryUtil.getLog(DLFileEntryListener.class);

	protected String fullPath(DLFileEntry file) throws PortalException {
		String fileName = file.getFileName();
		DLFolder folder = file.getFolder();

		if (folder == null) {
			return "/" + fileName;
		} else {
			return fullPath(folder) + "/" + fileName;
		}

	}

	protected String fullPath(DLFolder folder) throws PortalException {
		String folderName = folder.getName();
		DLFolder parent = folder.getParentFolder();

		if (parent == null) {
			// System.out.println("in parent null is "+"/" + folderName);
			return "/" + folderName;
		} else {
			// System.out.println("in parent null else is "+fullPath(parent) + "/" +
			// folderName);
			return fullPath(parent) + "/" + folderName;
		}

	}

}
